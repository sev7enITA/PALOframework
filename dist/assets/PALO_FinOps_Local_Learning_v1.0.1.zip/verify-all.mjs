import {readFile,readdir} from 'node:fs/promises';
import {verifyLearningReport} from './assets/palo-finops-learning.js';
const base=new URL('./examples/',import.meta.url);
const names=(await readdir(base)).filter(n=>n.endsWith('.json')&&!n.endsWith('.report.json'));
for(const name of names){
 const input=JSON.parse(await readFile(new URL(name,base)));
 const report=JSON.parse(await readFile(new URL(name.replace(/\.json$/,'.report.json'),base)));
 await verifyLearningReport(report,input);
 console.log(name+': exact replay verified');
}
console.log(names.length+' synthetic scenarios verified; no provider calls or training.');
