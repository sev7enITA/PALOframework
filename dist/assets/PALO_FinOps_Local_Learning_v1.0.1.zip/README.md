# PALO FinOps: Local learning reproduction 1.0.1

Created and maintained by Fabrizio Degni. Experimental offline evaluator, 22 October 2026.
Input and plan contracts: 1.0.0. Report contract: 1.0.1. Regenerate older reports.
This package is separate from the original FinOps v1.0 preprint.

With Node.js 22 or 24, run `node verify-all.mjs` from this directory.
Replay needs no dependency installation, model endpoint or credentials.
For the test suite, run `npm ci --ignore-scripts` and `npm test`.
The installation downloads the pinned schema-test dependencies; tests and replay make no model calls.

The seven experiment/report pairs are synthetic examples, not measured performance or savings.
Read docs/palo-finops-learning.md for full accounting and sampling assumptions.
The manifest checks bytes, not independent provenance or authenticity.
See https://paloframework.org/docs/palo-finops-local-learning-research.html for current research status.
